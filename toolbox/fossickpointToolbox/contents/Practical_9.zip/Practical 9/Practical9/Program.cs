﻿using System;
using System.Collections.Generic;

namespace Practical9
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] testGrid = {
                "T  B     G",
                "I  A  H  R",
                "GUMTREE  E",
                "E   O AXLE",
                "R COURT IN",
                "    N   N ",
                "O   D FRED",
                "PLATE    A",
                "A   R    R",
                "L   S    K"};

            Grid grid = new Grid(testGrid);
            
            foreach(string s in grid.horizontalLocations())
                Console.WriteLine(s);
            Console.ReadLine();
        }
    }
}