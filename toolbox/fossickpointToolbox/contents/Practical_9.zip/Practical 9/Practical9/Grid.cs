﻿using System.Collections.Generic;

namespace Practical9
{
    class Grid
    {
        private char[,] Data { get; set; }
        private int Rows { get; set; }
        private int Columns { get; set; }

        public Grid(string[] data)
        {
            Rows = data.Length;
            Columns = data[0].Length;

            Data = new char[Rows, Columns];
            for (int r = 0; r < Rows; r++)
                for (int c = 0; c < Columns; c++)
                    Data[r, c] = ' ';

            int row = 0;
            foreach (string s in data)
            {
                int col = 0;
                foreach (char ch in s)
                {
                    Data[row, col] = ch;
                    col++;
                }
                row++;
            }
        }

        public List<string> horizontalLocations()
        {
            List<string> locations = new List<string>();

            // Students need to write code here.

            return (locations);
        }
    }
}